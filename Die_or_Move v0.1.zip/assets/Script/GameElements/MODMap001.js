
var o0 = require('o0');
var o0CC = require('o0CC');
var o0Game = require('o0Game');

cc.Class({
    extends: cc.Component,

    properties: {
        initPositions:[],
    },

    // use this for initialization
    onLoad: function () {
        this.node.tag = o0Game.Tag.Ground;

        this.initPositions.push(cc.v2(300,120));
        this.initPositions.push(cc.v2(-300,120));
        this.initPositions.push(cc.v2(700,120));
        this.initPositions.push(cc.v2(-700,120));



        o0CC.addSprite(this.node,'maps/BG');
        var rigidBody = this.node.addComponent(cc.RigidBody);
        rigidBody.type = cc.RigidBodyType.Static;
        var collider = this.node.addComponent(cc.PhysicsPolygonCollider);
        //o0CC.addSpriteNode(null,'maps/BG');
        collider.points = [cc.v2(-40,-300),
            cc.v2(40,-300),
            cc.v2(830,100),
            cc.v2(830,370),
            cc.v2(700,430),
            cc.v2(-700,430),
            cc.v2(-830,370),
            cc.v2(-830,100),
            cc.v2(-40,-300),
            cc.v2(-960,-540),
            cc.v2(-960,540),
            cc.v2(960,540),
            cc.v2(960,-540),
            cc.v2(-960,-540)];
        collider.apply();

        var block1 = o0CC.addNode(this.node,0,cc.RigidBody,cc.PhysicsPolygonCollider);
        block1.tag = o0Game.Tag.Ground;
        block1.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
        var collider1 = block1.getComponent(cc.PhysicsPolygonCollider);
        collider1.points = [cc.v2(-300,-37),
            cc.v2(-300,29),
            cc.v2(-100,29),
            cc.v2(-100,-37)];
        collider1.apply();

        var block2 = o0CC.addNode(this.node,0,cc.RigidBody,cc.PhysicsPolygonCollider);
        block2.tag = o0Game.Tag.Ground;
        block2.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
        var collider2 = block2.getComponent(cc.PhysicsPolygonCollider);
        collider2.points = [cc.v2(166,-37),
            cc.v2(166,29),
            cc.v2(300,29),
            cc.v2(300,-37)];
        collider2.apply();
    },

    // called every frame
    update: function (dt) {
    }
});


