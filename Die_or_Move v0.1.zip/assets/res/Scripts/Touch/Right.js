var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.on(cc.Node.EventType.TOUCH_START,function(event){
            GLB.moveRight = true;
        });

        this.node.on(cc.Node.EventType.TOUCH_END,function(event){
            GLB.moveRight = false;
        });

        /*this.node.on('touchcancel',function(event){
            GLB.moveRight = false;
        });*/
    },

    start () {
    },

    // update (dt) {},
});