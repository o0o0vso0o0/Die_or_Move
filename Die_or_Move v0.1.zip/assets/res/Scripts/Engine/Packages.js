//初始化网络数据包
var playerFrameEvent ={
    type: 'player',
    speedNet: null,
    positionNet: null
};

var starPositionEvent ={
    type: 'createStar',
    positionNet: null
};

var scoreBroadcastEvent ={
    type: 'scoreBroadcast',
    score: null
};

var playerStatusEvent ={
    type: 'playerStatus',
    status: null
};

var gameStatusEvent ={
    type: 'gameStatus',
    status: null
};

module.exports = {
    playerFrameEvent: playerFrameEvent,
    starPositionEvent: starPositionEvent,
    scoreBroadcastEvent: scoreBroadcastEvent,
    playerStatusEvent: playerStatusEvent,
    gameStatusEvent: gameStatusEvent,
};