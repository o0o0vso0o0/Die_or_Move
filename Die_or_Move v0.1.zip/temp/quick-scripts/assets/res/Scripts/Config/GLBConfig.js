(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Config/GLBConfig.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8637elkqU1NhJn0pS/P5GNg', 'GLBConfig', __filename);
// res/Scripts/Config/GLBConfig.js

'use strict';

var GLBConfig = {
    maxPlayer: 2,

    gameStartEvent: 'gameStart',

    channel: 'MatchVS',
    platform: 'alpha',
    gameId: 201664,
    gameVersion: 1,
    appKey: '11979f08e9994333b0a6d2b446615ab2',
    secret: 'b787306cd12749b09a42ce83233bda85',

    deviceId: 'abcdef',
    gatewayId: 0,

    frameSync: 20,

    solo: false,
    userInfo: null,
    playerUserIds: [],
    isRoomOwner: false,
    events: {},

    moveLeft: false,
    moveRight: false,
    jumpUp: false,

    //抓星星模式
    catchDistance: 50
};
module.exports = GLBConfig;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GLBConfig.js.map
        