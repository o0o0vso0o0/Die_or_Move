(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Engine/Packages.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4ee25aFeJNHooXmxbJYYFhe', 'Packages', __filename);
// res/Scripts/Engine/Packages.js

'use strict';

//初始化网络数据包
var playerFrameEvent = {
    type: 'player',
    speedNet: null,
    positionNet: null
};

var starPositionEvent = {
    type: 'createStar',
    positionNet: null
};

var scoreBroadcastEvent = {
    type: 'scoreBroadcast',
    score: null
};

var playerStatusEvent = {
    type: 'playerStatus',
    status: null
};

var gameStatusEvent = {
    type: 'gameStatus',
    status: null
};

module.exports = {
    playerFrameEvent: playerFrameEvent,
    starPositionEvent: starPositionEvent,
    scoreBroadcastEvent: scoreBroadcastEvent,
    playerStatusEvent: playerStatusEvent,
    gameStatusEvent: gameStatusEvent
};

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Packages.js.map
        