(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Touch/Up.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '9e93aGE6pFJmKa38eizxEIf', 'Up', __filename);
// res/Scripts/Touch/Up.js

'use strict';

var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on('touchstart', function (event) {
            GLB.jumpUp = true;
        });

        this.node.on('touchend', function (event) {
            GLB.jumpUp = false;
        });

        this.node.on('touchcancel', function (event) {
            GLB.jumpUp = false;
        });
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Up.js.map
        