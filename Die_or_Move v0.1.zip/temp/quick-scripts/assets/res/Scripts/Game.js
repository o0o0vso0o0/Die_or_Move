(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Game.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4f22c3Vul9CPr2L2OTpLoK4', 'Game', __filename);
// res/Scripts/Game.js

'use strict';

var mvs = require('Mvs');
var GLB = require('GLBConfig');
var pkg = require('Packages');
var Init = require('Initialize');
var Basic = require('Basic');

cc.Class({
    extends: cc.Component,

    //定义节点内容
    properties: {
        //基础
        target: {
            default: null,
            type: cc.Button
        },

        player: {
            default: null,
            type: cc.Node
        },

        //角色
        maxSpeed: 500,
        jumps: 2,
        acceleration: 1500,
        jumpSpeed: 200,
        dieTime: 10,

        //功能
        deathTimer: {
            default: null,
            type: cc.Label
        },

        //抓星星模式
        starPrefab: {
            default: null,
            type: cc.Prefab
        },

        scoreBoard: {
            default: null,
            type: cc.Label
        },
        starTime: 3
    },

    //游戏功能性部分
    //杀死玩家 多人游戏支持已完成
    killPlayer: function killPlayer() {
        //this.player.destroy();
        this.live = false;
        try {
            this.unschedule(this.timer);
        } catch (e) {};
        this.deathTimer.string = 'You are dead!!';
        pkg.playerStatusEvent.status = 'dead';
        this.player.scaleY = -1;
        mvs.engine.sendFrameEvent(JSON.stringify(pkg.playerStatusEvent));
        this.playerLeft--;
        if (GLB.isRoomOwner && this.playerLeft <= 1) {
            pkg.gameStatusEvent.status = 'gameOver';
            mvs.engine.sendFrameEvent(JSON.stringify(pkg.gameStatusEvent));
            try {
                this.newStar.destroy();
            } catch (e) {};
            try {
                this.unschedule(this.hostCreateStar);
            } catch (e) {};
            this.gameOver();
        }
    },


    //死亡计时器
    timer: function timer() {
        if (this.timeLeft <= 0) {
            this.killPlayer();
        } else {
            this.deathTimer.string = this.timeLeft.toFixed(1);
            this.schedule(this.timer, 0.1);
            this.timeLeft = this.timeLeft - 0.1;
        }
    },


    //结束游戏 多人游戏支持完成
    gameOver: function gameOver() {
        //处理胜负事件
        var maxIds = new Array();
        maxIds[0] = GLB.playerUserIds[0];
        for (var i = 1; i < GLB.maxPlayer; i++) {
            if (this.score[maxIds[0]] > this.score[GLB.playerUserIds[i]]) {} else if (this.score[maxIds[0]] === this.score[GLB.playerUserIds[i]]) {
                maxIds.push(GLB.playerUserIds[i]);
            } else {
                maxIds.splice(0, maxIds.length);
                maxIds[0] = GLB.playerUserIds[i];
            }
        };
        var result = false;
        for (var i = 0; i < maxIds.length; i++) {
            if (GLB.userInfo.id === maxIds[i]) {
                result = true;
                break;
            }
        }
        if (result) {
            this.deathTimer.string = 'Winner Winner\nYou Have Cancer';
        } else {
            this.deathTimer.string = 'Loser Loser\nEat Your Wiener';
        }

        //停止本机玩家行动（不播放死亡动画）
        this.live = false;
        this.unschedule(this.timer);

        /*
        创建返回菜单按钮并设置点击事件
        var button = cc.instantiate(this.target);
        this.node.addChild(button);
        this.target.setPosition(0,0);
        var clickEventHandler = new cc.Component.EventHandler();
        clickEventHandler.target = this.node;
        clickEventHandler.component = "Game";
        clickEventHandler.handler = "returnToMain";
        var click = button.getComponent(cc.Button);
        click.clickEvents.push(clickEventHandler);
        */
    },


    //回到主菜单
    returnToMain: function returnToMain(event, customEventData) {
        //清除缓存
        GLB.isRoomOwner = false;
        //退出房间
        mvs.engine.leaveRoom();
        //退出登录
        mvs.engine.logout();
        //反初始化
        mvs.engine.uninit();
        //加载主菜单场景
        cc.director.loadScene("Start");
    },


    //摘星星模式部分
    //更新分数
    setScore: function setScore() {
        this.scoreBoard.string = '分数';
        for (var i = 0; i < GLB.maxPlayer; i++) {
            if (GLB.isRoomOwner && this.score[GLB.playerUserIds[i]] >= 5) {
                pkg.gameStatusEvent.status = 'gameOver';
                mvs.engine.sendFrameEvent(JSON.stringify(pkg.gameStatusEvent));
                try {
                    this.newStar.destroy();
                } catch (e) {};
                this.unschedule(this.hostCreateStar);
                this.gameOver();
            } else {
                this.scoreBoard.string += '\n' + GLB.playerUserIds[i] + '  ' + this.score[GLB.playerUserIds[i]];
            }
        };
    },

    //发出分数信息
    sendScore: function sendScore() {
        pkg.scoreBroadcastEvent.score = this.score[GLB.userInfo.id];
        mvs.engine.sendFrameEvent(JSON.stringify(pkg.scoreBroadcastEvent));
    },

    //创建新的星星
    createNewStar: function createNewStar(x, y) {
        try {
            this.newStar.destroy();
        } catch (e) {};
        this.newStar = cc.instantiate(this.starPrefab);
        this.node.addChild(this.newStar);
        this.newStar.setPosition(x, y);
        this.newStar.getComponent('Star').game = this;
    },

    //房主调用 决定星星生成并广播星星生成位置
    hostCreateStar: function hostCreateStar() {
        pkg.starPositionEvent.positionNet = cc.v2();
        this.starPositionX = (Math.random() - 0.5) * 900;
        this.starPositionY = (Math.random() - 0.5) * 600;
        pkg.starPositionEvent.positionNet.x = this.starPositionX;
        pkg.starPositionEvent.positionNet.y = this.starPositionY;
        this.createNewStar(pkg.starPositionEvent.positionNet);
        mvs.engine.sendFrameEvent(JSON.stringify(pkg.starPositionEvent));
        this.schedule(this.hostCreateStar, this.starTime);
    },


    //初始化
    onLoad: function onLoad() {
        console.log(GLB.playerUserIds);
        //启动物理系统
        cc.director.getPhysicsManager().enabled = true;

        //初始化Players对象
        function Players() {
            this.node = null;
            this.body = null;
            this.live = true;
        };

        //需要改写以适应多玩家（已完成）
        //初始化本地所需变量
        //移动 速度 刚体组件部分
        GLB.moveLeft = false;
        GLB.moveRight = false;
        GLB.jumpUp = false;
        this.vyzero = false;
        this.jump = this.jumps;
        this.body = this.player.getComponent(cc.RigidBody);
        this.speed = null;

        //动画补正缓存
        this.speedCache = cc.v2();
        this.xCorrection = 0;
        this.yCorrection = 0;

        //游戏功能内容部分
        this.timeLeft = null;
        this.live = true;
        this.playerLeft = GLB.maxPlayer;

        //抓星星所需变量
        this.newStar = null;
        this.score = new Array();
        this.starPositionX = null;
        this.starPositionY = null;

        //初始化其他玩家
        this.players = new Array();
        console.log(GLB.playerUserIds);
        for (var i = 0; i < GLB.maxPlayer; i++) {
            //初始化player数组，将玩家ID作为数组成员序号
            if (GLB.playerUserIds[i] !== GLB.userInfo.id) {
                this.players[GLB.playerUserIds[i]] = new Players();
                this.players[GLB.playerUserIds[i]].node = cc.instantiate(this.player);
                this.node.addChild(this.players[GLB.playerUserIds[i]].node);
                this.players[GLB.playerUserIds[i]].body = this.players[GLB.playerUserIds[i]].node.getComponent(cc.RigidBody);
                this.players[GLB.playerUserIds[i]].node.setPosition(0, 0);
            }
            //初始化score数组，将玩家ID作为数组成员序号
            this.score[GLB.playerUserIds[i]] = 0;
        };

        //初始化输入
        Init.setInputControl();

        //启动死亡计时器
        this.timeLeft = this.dieTime;

        //初始化帧同步系统
        mvs.response.frameUpdate = this.frameUpdate.bind(this);

        //如果是房主，设定帧同步速率
        if (GLB.isRoomOwner) {
            mvs.response.setFrameSyncResponse = Init.setFrameSyncResponse.bind(this);
            mvs.engine.setFrameSync(GLB.frameSync);
        }
        mvs.response.sendFrameEventResponse = Init.sendFrameEventResponse.bind(this);

        //如果是房主，间隔一定时间创建新星星并公示位置
        console.log(GLB.isRoomOwner);
        if (GLB.isRoomOwner) {
            this.schedule(this.hostCreateStar, 0);
        }

        //初始化计分板
        this.setScore();
    },


    //帧同步回调
    frameUpdate: function frameUpdate(data) {
        console.log(data.frameWaitCount);
        for (var i = 0; i < data.frameWaitCount; i++) {
            //如果接收到非本机ID包
            if (data.frameItems[i].srcUserID !== GLB.userInfo.id) {
                //如果是角色移动消息
                if (JSON.parse(data.frameItems[i].cpProto).type === 'player') {
                    //进行动画修饰（还行）
                    //偏差不大时进行速度补正
                    if (Math.abs(this.players[data.frameItems[i].srcUserID].node.position.x - JSON.parse(data.frameItems[i].cpProto).positionNet.x) < 30 && Math.abs(this.players[data.frameItems[i].srcUserID].node.position.y - JSON.parse(data.frameItems[i].cpProto).positionNet.y) < 100) {
                        this.xCorrection = 10 * (JSON.parse(data.frameItems[i].cpProto).positionNet.x - this.players[data.frameItems[i].srcUserID].node.position.x);
                        this.yCorrection = 10 * (JSON.parse(data.frameItems[i].cpProto).positionNet.y - this.players[data.frameItems[i].srcUserID].node.position.y);
                        this.speedCache.x = JSON.parse(data.frameItems[i].cpProto).speedNet.x + this.xCorrection;
                        this.speedCache.y = JSON.parse(data.frameItems[i].cpProto).speedNet.y + this.yCorrection;
                        this.players[data.frameItems[i].srcUserID].body.linearVelocity = this.speedCache;
                    } else {
                        this.players[data.frameItems[i].srcUserID].body.linearVelocity = JSON.parse(data.frameItems[i].cpProto).speedNet;
                        this.players[data.frameItems[i].srcUserID].node.position = JSON.parse(data.frameItems[i].cpProto).positionNet;
                    }
                    //控制角色面部朝向
                    if (this.players[data.frameItems[i].srcUserID].body.linearVelocity.x > 0) {
                        this.players[data.frameItems[i].srcUserID].node.scaleX = 1;
                    } else if (this.players[data.frameItems[i].srcUserID].body.linearVelocity.x < 0) {
                        this.players[data.frameItems[i].srcUserID].node.scaleX = -1;
                    }
                }
                //如果是星星生成消息
                else if (JSON.parse(data.frameItems[i].cpProto).type === 'createStar') {
                        try {
                            this.newStar.destroy();
                        } catch (e) {};
                        this.createNewStar(JSON.parse(data.frameItems[i].cpProto).positionNet);
                    }
                    //如果是分数通知
                    else if (JSON.parse(data.frameItems[i].cpProto).type === 'scoreBroadcast') {
                            this.score[data.frameItems[i].srcUserID] = JSON.parse(data.frameItems[i].cpProto).score;
                            this.setScore();
                        }
                        //如果是玩家状态通知
                        else if (JSON.parse(data.frameItems[i].cpProto).type === 'playerStatus') {
                                if (JSON.parse(data.frameItems[i].cpProto).status === 'dead') {
                                    this.players[data.frameItems[i].srcUserID].live = false;
                                    this.players[data.frameItems[i].srcUserID].node.scaleY = -1;
                                    this.playerLeft--;
                                    if (GLB.isRoomOwner && this.playerLeft <= 1) {
                                        pkg.gameStatusEvent.status = 'gameOver';
                                        mvs.engine.sendFrameEvent(JSON.stringify(pkg.gameStatusEvent));
                                        try {
                                            this.newStar.destroy();
                                        } catch (e) {};
                                        this.unschedule(this.hostCreateStar);
                                        this.gameOver();
                                    }
                                }
                            }
                            //如果是游戏状态通知
                            else if (JSON.parse(data.frameItems[i].cpProto).type === 'gameStatus') {
                                    if (JSON.parse(data.frameItems[i].cpProto).status === 'gameOver') {
                                        try {
                                            this.newStar.destroy();
                                        } catch (e) {};
                                        this.gameOver();
                                    }
                                }
            } else {
                //收到本机ID包
            }
        };
    },


    //帧更新内容
    update: function update(dt) {
        if (this.live) {
            this.speed = this.body.linearVelocity;

            if (GLB.moveLeft) {
                this.speed.x -= this.acceleration * dt;
                // this.anim.play('walk');仅占位，需要判断是否滞空
            } else if (GLB.moveRight) {
                this.speed.x += this.acceleration * dt;
                // this.anim.play('walk');仅占位，需要判断是否滞空
            }
            if (this.speed.x < -this.maxSpeed) {
                this.speed.x = -this.maxSpeed;
            } else if (this.speed.x > this.maxSpeed) {
                this.speed.x = this.maxSpeed;
            }

            if (Math.abs(this.speed.y) === 0) {
                if (!this.vyzero) {
                    this.vyzero = true;
                } else if (this.vyzero) {
                    this.jump = this.jumps;
                    this.vyzero = false;
                }
            }

            if (this.jump > 0 && GLB.jumpUp) {
                this.speed.y = this.jumpSpeed;
                this.jump--;
            }

            if (this.speed.x > 0) {
                this.player.scaleX = 1;
            } else if (this.speed.x < 0) {
                this.player.scaleX = -1;
            }

            GLB.jumpUp = false;

            //判断是否移动重置死亡计时器
            if (this.speed.x === 0 && this.speed.y === 0) {} else {
                this.timeLeft = this.dieTime;
                this.unschedule(this.timer);
                this.timer();
            }
        }
        if (GLB.solo == true) {
            for (var i = 0; i < GLB.maxPlayer; i++) {
                if (GLB.playerUserIds[i] !== GLB.userInfo.id) {
                    this.speedCache = this.players[GLB.playerUserIds[i]].body.linearVelocity;
                    if (this.players[GLB.playerUserIds[i]].node.position.x < this.starPositionX) {
                        this.speedCache.x += this.acceleration * dt;
                        if (this.speedCache.x > this.maxSpeed) {
                            this.speedCache.x = this.maxSpeed;
                        }
                    } else {
                        this.speedCache.x -= this.acceleration * dt;
                        if (this.speedCache.x < -this.maxSpeed) {
                            this.speedCache.x = -this.maxSpeed;
                        }
                    }
                    if (Math.abs(this.players[GLB.playerUserIds[i]].node.position.x - this.starPositionX) < 100 && this.players[GLB.playerUserIds[i]].node.position.y - this.starPositionY < 0) {
                        this.speedCache.y += this.acceleration * dt;
                    }
                    this.players[GLB.playerUserIds[i]].body.linearVelocity = this.speedCache;
                }
            }
        }
        this.body.linearVelocity = this.speed;

        pkg.playerFrameEvent.speedNet = this.speed;
        pkg.playerFrameEvent.positionNet = this.player.getPosition();
        mvs.engine.sendFrameEvent(JSON.stringify(pkg.playerFrameEvent));
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Game.js.map
        