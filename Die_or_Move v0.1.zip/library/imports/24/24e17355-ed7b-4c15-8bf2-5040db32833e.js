"use strict";
cc._RF.push(module, '24e17NV7XtMFYvyUEDbMoM+', 'Right');
// res/Scripts/Touch/Right.js

'use strict';

var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            GLB.moveRight = true;
        });

        this.node.on(cc.Node.EventType.TOUCH_END, function (event) {
            GLB.moveRight = false;
        });

        /*this.node.on('touchcancel',function(event){
            GLB.moveRight = false;
        });*/
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();