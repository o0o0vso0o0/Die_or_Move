"use strict";
cc._RF.push(module, 'b26d9lv8i5PTYyP28H8jQMT', 'Start');
// res/Scripts/Start.js

'use strict';

var mvs = require('Mvs');
var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {
        labelInfo: {
            default: null,
            type: cc.Label
        }
    },

    labelLog: function labelLog(info) {
        this.labelInfo.string += '\n' + info;
    },

    onLoad: function onLoad() {
        this.btnClickTime = 0;
    },


    //初始化+注册
    online: function online() {
        //覆写Mvs引擎网络相关回调函数
        mvs.response.initResponse = this.initResponse.bind(this);
        mvs.response.registerUserResponse = this.registerUserResponse.bind(this);
        mvs.response.loginResponse = this.loginResponse.bind(this);
        mvs.response.joinRoomResponse = this.joinRoomResponse.bind(this);
        mvs.response.joinOverResponse = this.joinOverResponse.bind(this);
        mvs.response.sendEventNotify = this.sendEventNotify.bind(this);
        mvs.response.sendEventResponse = this.sendEventResponse.bind(this);
        mvs.response.joinRoomNotify = this.joinRoomNotify.bind(this);
        //开始初始化
        mvs.engine.init(mvs.response, GLB.channel, GLB.platform, GLB.gameId);
    },
    initResponse: function initResponse(status) {
        this.labelLog('初始化完成');
        if (GLB.userInfo !== null) {
            this.labelLog('开始登陆，用户Id：' + GLB.userInfo.id);
            var result = mvs.engine.login(GLB.userInfo.id, GLB.userInfo.token, GLB.gameId, GLB.gameVersion, GLB.appKey, GLB.secret, GLB.deviceId, GLB.gatewayId);
            if (result !== 0) this.labelLog('登陆失败，错误码：' + result);
        } else {
            this.labelLog('开始注册');
            var result = mvs.engine.registerUser();
            if (result !== 0) this.labelLog('注册失败，错误码：' + result);
        }
    },


    //注册回调+登陆
    registerUserResponse: function registerUserResponse(userInfo) {
        GLB.userInfo = userInfo;

        this.labelLog('开始登陆，用户Id：' + userInfo.id);
        var result = mvs.engine.login(userInfo.id, userInfo.token, GLB.gameId, GLB.gameVersion, GLB.appKey, GLB.secret, GLB.deviceId, GLB.gatewayId);
        if (result !== 0) this.labelLog('登陆失败，错误码：' + result);
    },


    //登陆回调+进入房间
    loginResponse: function loginResponse(loginRsp) {
        this.labelLog('登陆成功');
        this.labelLog('开始加入随机房间');
        var result = mvs.engine.joinRandomRoom(GLB.maxPlayer, '');
        if (result !== 0) this.labelLog('加入房间失败，错误码' + result);
    },


    //进入房间回调
    joinRoomResponse: function joinRoomResponse(status, userInfoList, roomInfo) {
        if (status !== 200) {
            this.labelLog('进入房间失败，错误码：' + status);
        } else {
            this.labelLog('进入房间成功，房间号：' + roomInfo.roomId + '\n游戏共需玩家人数：' + GLB.maxPlayer);

            var userIds = [GLB.userInfo.id];
            userInfoList.forEach(function (item) {
                if (GLB.userInfo.id !== item.userId) userIds.push(item.userId);
            });
            this.labelLog('房间用户: ' + userIds);

            //是否是最后一个进入的玩家，如果是，开始关闭房间
            if (userIds.length >= GLB.maxPlayer) {
                var result = mvs.engine.joinOver("");
                this.labelLog("发出关闭房间的通知");
                if (result !== 0) {
                    this.labelLog("关闭房间失败，错误码：", result);
                }
                GLB.playerUserIds = userIds;
            }
            //如果非最后一个进入的玩家，等待开始通知
        };
    },

    //停止加入房间回调
    joinOverResponse: function joinOverResponse(joinOverRsp) {
        if (joinOverRsp.status === 200) {
            this.labelLog('关闭房间成功，可以开始游戏了！');
            //令最后一个加入的人成为房主
            GLB.isRoomOwner = true;
            this.labelLog('发送启动游戏命令');
            //设置发送的消息
            var event = {
                //发送游戏开始命令
                action: GLB.gameStartEvent,
                //发送所有玩家id
                userIds: GLB.playerUserIds
            };
            //设置发送事件回调
            var result = mvs.engine.sendEvent(JSON.stringify(event));
            if (result.result !== 0) this.labelLog('发送游戏开始通知失败，错误码：' + result.result);
            //将此event以对应sequence存入缓存
            GLB.events[result.sequence] = event;
            this.labelLog('发起游戏开始通知，等待回复');
        } else {
            this.labelLog('关闭房间失败，错误代码：' + joinOverRsp.status);
        }
    },

    //发送消息回调
    sendEventResponse: function sendEventResponse(info) {
        if (!info || !info.status || info.status !== 200) {
            this.labelLog('事件发送失败');
        }

        //根据返回的event sequence来查找缓存中的对应event
        var event = GLB.events[info.sequence];

        //如果发送的事件是开始游戏事件
        if (event && event.action === GLB.gameStartEvent) {
            //删除event缓存
            delete GLB.events[info.sequence];
            //启动游戏

            cc.director.loadScene("Test");
        }
    },
    sendEventNotify: function sendEventNotify(info) {
        if (JSON.parse(info.cpProto).action === GLB.gameStartEvent) {

            GLB.playerUserIds = [GLB.userInfo.id];
            // 发起开始游戏的玩家会把userIds传过来，这里找出所有除本玩家之外的用户ID，
            // 添加到全局变量playerUserIds中
            JSON.parse(info.cpProto).userIds.forEach(function (userId) {
                if (userId !== GLB.userInfo.id) GLB.playerUserIds.push(userId);
            });

            cc.director.loadScene("Test");
        }
    },
    joinRoomNotify: function joinRoomNotify(userID, roomUserInfo) {
        this.labelLog('一位新玩家加入');
    },
    start: function start() {},


    //单人测试按钮对应函数
    btnClick: function btnClick(event, customEventData) {
        var _this = this;

        GLB.solo = true;
        GLB.isRoomOwner = true;
        GLB.userInfo = {
            id: 0
        };
        for (var i = 0; i < GLB.maxPlayer; i++) {
            GLB.playerUserIds.push(i);
        }
        if (this.btnClickTime == 0) {
            this.labelLog("正在匹配：");
        } else {
            this.labelLog("匹配中，请稍后");
        }
        this.btnClickTime++;
        setTimeout(function () {
            _this.labelLog("匹配成功！");
            cc.director.loadScene("Test");
        }, Math.random() * 3000);
    },
    update: function update(dt) {}
});

cc._RF.pop();