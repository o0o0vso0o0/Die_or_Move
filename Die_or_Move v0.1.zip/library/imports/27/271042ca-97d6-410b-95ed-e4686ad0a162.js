"use strict";
cc._RF.push(module, '27104LKl9ZBC5Xt5Ghq0KFi', 'Initialize');
// res/Scripts/Engine/Initialize.js

'use strict';

var GLB = require("GLBConfig");
//初始化输入
function setInputControl() {
    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, function (event) {
        switch (event.keyCode) {
            case cc.KEY.a:
                GLB.moveLeft = true;
                break;
            case cc.KEY.d:
                GLB.moveRight = true;
                break;
            case cc.KEY.space:
                GLB.jumpUp = true;
                break;
        }
    });
    cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, function (event) {
        switch (event.keyCode) {
            case cc.KEY.a:
                GLB.moveLeft = false;
                break;
            case cc.KEY.d:
                GLB.moveRight = false;
                break;
        }
    });
}

//设置帧同步速率回调
function setFrameSyncResponse(status) {
    console.log('设置帧同步速率为：' + GLB.frameSync);
    if (status.mStatus !== 200) {
        console.log('设置同步速率失败，错误码：' + status.mStatus);
    } else {
        console.log('设置同步帧率成功');
    };
}

//帧同步消息回调
function sendFrameEventResponse(status) {
    if (status.mStatus !== 200) {
        console.log('同步消息发送失败，错误码：' + status.mStatus);
    } else {
        console.log('同步消息发送成功');
    }
}

module.exports = {
    setInputControl: setInputControl,
    setFrameSyncResponse: setFrameSyncResponse,
    sendFrameEventResponse: sendFrameEventResponse
};

cc._RF.pop();