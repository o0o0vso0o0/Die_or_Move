(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Engine/OneSidePlatform.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2f5ccbZ2JZHVKzmwRI9YQxr', 'OneSidePlatform', __filename);
// res/Scripts/Engine/OneSidePlatform.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    onLoad: function onLoad() {
        this.pointVelPlatform = cc.v2();
        this.pointVelOther = cc.v2();
        this.relativeVel = cc.v2();
        this.relativePoint = cc.v2();
    },

    onBeginContact: function onBeginContact(contact, selfCollider, otherCollider) {
        var otherBody = otherCollider.body;
        var platformBody = selfCollider.body;

        var worldManifold = contact.getWorldManifold();
        var points = worldManifold.points;

        var pointVelPlatform = this.pointVelPlatform;
        var pointVelOther = this.pointVelOther;
        var relativeVel = this.relativeVel;
        var relativePoint = this.relativePoint;

        //检测物体是否来自下方
        for (var i = 0; i < points.length; i++) {
            platformBody.getLinearVelocityFromWorldPoint(points[i], pointVelPlatform);
            otherBody.getLinearVelocityFromWorldPoint(points[i], pointVelOther);
            platformBody.getLocalVector(pointVelOther.subSelf(pointVelPlatform), relativeVel);

            if (relativeVel.y < 2) //如果相对下落速度大于 32 pixel/s (1m/s), 正常碰撞
                return;else {
                //向上移动速度超过 1 m/s
            }
        }

        // 禁用碰撞
        contact.disabled = true;
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=OneSidePlatform.js.map
        