(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Modes/CatchStars/Star.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '554e3YUkAxOB4ou5qJvRnXk', 'Star', __filename);
// res/Scripts/Modes/CatchStars/Star.js

'use strict';

var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {
        pickRadius: 50
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    update: function update(dt) {
        if (this.node.position.sub(this.game.player.getPosition()).mag() < GLB.catchDistance) {
            this.game.score[GLB.userInfo.id]++;
            this.game.setScore();
            this.game.sendScore();
            this.node.destroy();
        } else if (GLB.solo) {
            for (var i = 1; i < GLB.maxPlayer; i++) {
                if (this.node.position.sub(this.game.players[GLB.playerUserIds[i]].node.position).mag() < GLB.catchDistance) {
                    this.game.score[GLB.playerUserIds[i]]++;
                    this.game.setScore();
                    this.node.destroy();
                }
            }
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Star.js.map
        