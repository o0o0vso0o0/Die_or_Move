"use strict";
cc._RF.push(module, 'adf525QF1pMfIeQ8oGfn95t', 'Mvs');
// res/Scripts/Engine/Mvs.js

"use strict";

var engine;
var response = {};
try {
    engine = Matchvs.MatchvsEngine.getInstance();
} catch (e) {
    try {
        var jsMatchvs = require("matchvs.all");
        engine = new jsMatchvs.MatchvsEngine();
        response = new jsMatchvs.MatchvsResponse();
    } catch (e) {
        var MatchVSEngine = require('MatchvsEngine');
        engine = new MatchVSEngine();
    }
}
module.exports = {
    engine: engine,
    response: response
};

cc._RF.pop();