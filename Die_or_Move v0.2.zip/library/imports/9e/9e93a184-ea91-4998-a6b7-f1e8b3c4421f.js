"use strict";
cc._RF.push(module, '9e93aGE6pFJmKa38eizxEIf', 'Up');
// res/Scripts/Touch/Up.js

'use strict';

var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on('touchstart', function (event) {
            GLB.jumpUp = true;
        });

        this.node.on('touchend', function (event) {
            GLB.jumpUp = false;
        });

        this.node.on('touchcancel', function (event) {
            GLB.jumpUp = false;
        });
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();