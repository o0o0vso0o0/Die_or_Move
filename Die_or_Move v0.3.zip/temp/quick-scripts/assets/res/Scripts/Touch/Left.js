(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/res/Scripts/Touch/Left.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8f2e3TMsFZIA57DH6r11J0z', 'Left', __filename);
// res/Scripts/Touch/Left.js

'use strict';

var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.node.on(cc.Node.EventType.TOUCH_START, function (event) {
            GLB.moveLeft = true;
        });

        this.node.on(cc.Node.EventType.TOUCH_END, function (event) {
            GLB.moveLeft = false;
        });

        /*this.node.on('touchcancel',function(event){
            GLB.moveLeft = false;
        });*/
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Left.js.map
        