var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.node.on('touchstart',function(event){
            GLB.jumpUp = true;
        });

        this.node.on('touchend',function(event){
            GLB.jumpUp = false;
        });

        this.node.on('touchcancel',function(event){
            GLB.jumpUp = false;
        });
    },

    start () {
    },

    // update (dt) {},
});