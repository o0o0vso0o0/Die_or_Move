var GLBConfig = {
    maxPlayer: 2,

    gameStartEvent: 'gameStart',

    channel: 'MatchVS',
    platform: 'alpha',
    gameId: 201664,
    gameVersion: 1,
    appKey: '11979f08e9994333b0a6d2b446615ab2',
    secret: 'b787306cd12749b09a42ce83233bda85',

    deviceId: 'abcdef',
    gatewayId: 0,

    frameSync: 20,

    solo: false,
    userInfo: null,
    playerUserIds: [],
    isRoomOwner: false,
    events:{},

    moveLeft: false,
    moveRight: false,
    jumpUp: false,

    //抓星星模式
    catchDistance: 50,
};
module.exports = GLBConfig;