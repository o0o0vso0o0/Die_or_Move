cc.Class({
    extends: cc.Component,

    properties: {    },

    onLoad: function () {
        this.pointVelPlatform = cc.v2();
        this.pointVelOther = cc.v2();
        this.relativeVel = cc.v2();
        this.relativePoint = cc.v2();
    },

    onBeginContact: function (contact, selfCollider, otherCollider) {
        let otherBody = otherCollider.body;
        let platformBody = selfCollider.body;

        let worldManifold = contact.getWorldManifold();
        let points = worldManifold.points;

        let pointVelPlatform = this.pointVelPlatform;
        let pointVelOther = this.pointVelOther;
        let relativeVel = this.relativeVel;
        let relativePoint = this.relativePoint;

        //检测物体是否来自下方
        for (let i = 0; i < points.length; i++) {
            platformBody.getLinearVelocityFromWorldPoint( points[i], pointVelPlatform );
            otherBody.getLinearVelocityFromWorldPoint( points[i], pointVelOther );
            platformBody.getLocalVector( pointVelOther.subSelf(pointVelPlatform), relativeVel );
            
            if ( relativeVel.y < 2 ) //如果相对下落速度大于 32 pixel/s (1m/s), 正常碰撞
                return;
            else {
                //向上移动速度超过 1 m/s
            }
        }
        
        // 禁用碰撞
        contact.disabled = true;
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});
