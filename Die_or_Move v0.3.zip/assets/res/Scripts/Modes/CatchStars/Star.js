var GLB = require('GLBConfig');

cc.Class({
    extends: cc.Component,

    properties: {
        pickRadius: 50
    },



    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    update (dt) {
        if(this.node.position.sub(this.game.player.getPosition()).mag() < GLB.catchDistance){
            this.game.score[GLB.userInfo.id]++;
            this.game.setScore();
            this.game.sendScore();
            this.node.destroy();
        }
        else if(GLB.solo){
            for(var i = 1;i < GLB.maxPlayer;i++){
                if(this.node.position.sub(this.game.players[GLB.playerUserIds[i]].node.position).mag() < GLB.catchDistance){
                    this.game.score[GLB.playerUserIds[i]]++;
                    this.game.setScore();
                    this.node.destroy();
                }
            }
        }
    }
})